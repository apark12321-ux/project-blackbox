// 서버 컴포넌트 - 메타데이터 + JSON-LD 생성
// 본문 렌더링은 PostClient에 위임
import type { Metadata } from 'next';
import PostClient from './PostClient';

// Upstash에서 글 정보 가져오기 (서버 사이드)
async function fetchPost(slug: string) {
  try {
    const res = await fetch(`https://www.nutube.kr/api/posts/${slug}`, {
      next: { revalidate: 60 }, // 60초마다 재검증
    });
    if (!res.ok) return null;
    const json = await res.json();
    return json.success ? json.data : null;
  } catch {
    return null;
  }
}

const CATEGORY_LABELS: Record<string, string> = {
  algorithm: '알고리즘',
  senior: '시니어 사연 쇼츠',
  aitools: 'AI 도구',
  monetization: '수익화',
};

// SEO 메타데이터 동적 생성
export async function generateMetadata(
  { params }: { params: { slug: string } }
): Promise<Metadata> {
  const post = await fetchPost(params.slug);
  
  if (!post) {
    return {
      title: '가이드를 찾을 수 없습니다 - NuTube',
      description: '요청하신 가이드를 찾을 수 없습니다.',
    };
  }
  
  const catLabel = CATEGORY_LABELS[post.category] || '';
  const titleFull = `${post.title} - NuTube`;
  const description = post.summary || post.subtitle || post.title;
  const ogImage = `https://www.nutube.kr/thumbnails/${post.slug}.svg`;
  const url = `https://www.nutube.kr/blog/${post.slug}`;
  const keywords = Array.isArray(post.tags) ? post.tags : [];
  
  return {
    title: titleFull,
    description: description,
    keywords: [...keywords, catLabel, '유튜브', 'YouTube', '채널 운영', 'NuTube'].join(', '),
    authors: [{ name: post.author || '알고파트너스' }],
    alternates: { canonical: url },
    openGraph: {
      type: 'article',
      title: post.title,
      description: description,
      url: url,
      siteName: 'NuTube',
      locale: 'ko_KR',
      publishedTime: post.publishedAt,
      modifiedTime: post.updatedAt || post.publishedAt,
      authors: [post.author || '알고파트너스'],
      tags: keywords,
      images: [{
        url: ogImage,
        width: 1200,
        height: 630,
        alt: post.title,
      }],
    },
    twitter: {
      card: 'summary_large_image',
      title: post.title,
      description: description,
      images: [ogImage],
    },
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-image-preview': 'large',
        'max-snippet': -1,
        'max-video-preview': -1,
      },
    },
  };
}

export default async function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = await fetchPost(params.slug);
  
  // JSON-LD 구조화 데이터 (Article + BreadcrumbList + FAQ 자동 감지)
  const jsonLd: any = post ? {
    '@context': 'https://schema.org',
    '@type': 'Article',
    headline: post.title,
    description: post.summary,
    image: `https://www.nutube.kr/thumbnails/${post.slug}.svg`,
    datePublished: post.publishedAt,
    dateModified: post.updatedAt || post.publishedAt,
    author: {
      '@type': 'Organization',
      name: post.author || '알고파트너스',
      url: 'https://www.nutube.kr',
    },
    publisher: {
      '@type': 'Organization',
      name: 'NuTube',
      url: 'https://www.nutube.kr',
      logo: {
        '@type': 'ImageObject',
        url: 'https://www.nutube.kr/favicon.svg',
      },
    },
    mainEntityOfPage: {
      '@type': 'WebPage',
      '@id': `https://www.nutube.kr/blog/${post.slug}`,
    },
    keywords: (post.tags || []).join(', '),
    articleSection: CATEGORY_LABELS[post.category] || '',
  } : null;

  // 빵부스러기 (BreadcrumbList)
  const breadcrumb = post ? {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: '홈', item: 'https://www.nutube.kr' },
      { '@type': 'ListItem', position: 2, name: '가이드', item: 'https://www.nutube.kr/blog' },
      { '@type': 'ListItem', position: 3, name: post.title, item: `https://www.nutube.kr/blog/${post.slug}` },
    ],
  } : null;

  // FAQ 자동 추출 (본문에 '### Q.' 패턴이 있으면)
  let faqSchema: any = null;
  if (post?.content?.body) {
    const faqMatches = [...post.content.body.matchAll(/### Q\.\s+(.+?)\n+([\s\S]+?)(?=###|##|$)/g)];
    if (faqMatches.length > 0) {
      faqSchema = {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        mainEntity: faqMatches.map((m) => ({
          '@type': 'Question',
          name: m[1].trim(),
          acceptedAnswer: {
            '@type': 'Answer',
            text: m[2].trim().replace(/\n+/g, ' ').slice(0, 500),
          },
        })),
      };
    }
  }
  
  return (
    <>
      {jsonLd && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      )}
      {breadcrumb && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumb) }}
        />
      )}
      {faqSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
        />
      )}
      <PostClient slug={params.slug} initialPost={post} />
    </>
  );
}
