module.exports = { plugins: {} };
