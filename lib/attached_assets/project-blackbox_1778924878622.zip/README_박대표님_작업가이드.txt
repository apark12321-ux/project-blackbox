═════════════════════════════════════════════════════════
   NuTube 최종 정리본 - 박 대표님 작업 가이드
   (폴더가 완전히 비어있는 상태에서 시작)
═════════════════════════════════════════════════════════

박 대표님 컴퓨터의 project-blackbox 폴더가 비어있어도
이 가이드대로 따라하면 GitHub의 원본을 다시 받아서
이 ZIP 내용으로 깔끔하게 교체할 수 있습니다.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ 사전 안전 조치 ] GitHub에 백업 브랜치 만들기
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 반드시 먼저! 무언가 잘못되면 복원할 수 있게.

1. 웹브라우저에서 GitHub 접속:
   https://github.com/apark12321-ux/project-blackbox

2. 좌측 상단에 "main" 드롭다운 클릭

3. 검색창에 입력: backup-2026-05-16

4. "Create branch: backup-2026-05-16 from main" 클릭

→ 백업 완료!


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ Step 1 ] GitHub Desktop에서 저장소 새로 clone
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

박 대표님 컴퓨터의 project-blackbox 폴더가 비어있거나
.git 폴더가 없는 상태입니다.
GitHub에서 새로 다운로드 받습니다.

1. GitHub Desktop 열기

2. 상단 메뉴: File → Clone repository

3. 목록에서 "apark12321-ux/project-blackbox" 클릭

4. Local Path 지정:
   - 기존 project-blackbox 폴더가 비어있으면 다른 이름으로 받으세요
   - 예: project-blackbox-new
   - 또는 기존 폴더를 완전히 삭제한 뒤 같은 이름으로 받기

5. Clone 버튼 클릭

→ 다운로드 완료 (1~3분)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ Step 2 ] frontend 폴더 교체
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. GitHub Desktop에서 Repository → Show in Explorer
   (또는 Ctrl+Shift+F)

2. 윈도우 탐색기에서 "보기" → "숨김 항목" 체크
   → .git 폴더가 보일 거예요. 절대 손대지 마세요!

3. frontend 폴더 우클릭 → 삭제
   (.git 폴더는 그대로!)

4. 이 ZIP을 풀면 그 안에:
   nutube_FINAL/
   ├── .gitignore
   ├── README_박대표님_작업가이드.txt
   └── frontend/             ← 이 폴더를 통째로 복사!

5. ZIP의 frontend 폴더를 새 위치(project-blackbox/) 안에 붙여넣기

6. .gitignore도 같이 복사 (덮어쓰기 OK)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ Step 3 ] GitHub Desktop 변경사항 확인
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. GitHub Desktop 좌측 "Changes" 탭

2. 변경사항이 표시되어야 함:

   정상 ✅:
   - 수십~수백 개의 변경사항
   - 빨간색 (−): 삭제된 옛날 파일들
     · frontend/app/knowhow/ 안의 52개
     · frontend/app/keyword/ 안의 4개
     · frontend/app/plan/ 안의 4개
     · 기타 약 90개

   비정상 ❌:
   - 변경사항이 없음
   → frontend 폴더 복사가 제대로 안 된 것
   → ZIP에서 다시 frontend 폴더 복사


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ Step 4 ] Commit + Push
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. 좌측 하단 "Summary" 칸에 입력:
   Cleanup: Remove AlgoMaker, NuTube only

2. "Commit to main" 버튼 클릭

3. 우측 상단 "Push origin" 버튼 클릭

→ GitHub에 업로드 (1~2분)


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ Step 5 ] Vercel 자동 빌드 확인
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. 브라우저:
   https://vercel.com/yjparks-projects-18926ad8/project-blackbox-cpqy/deployments

2. 새 배포가 자동 시작
   - 노란색 "Building..."
   - 1~3분 후 초록색 "Ready"

3. 만약 빨간색 "Error" 뜨면:
   - 클릭 → 로그 확인 → 캡처해서 알려주세요


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ Step 6 ] 정상 작동 확인 (시크릿 창에서!)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 반드시 시크릿 창 (Ctrl+Shift+N)에서 확인!

NuTube 정상 표시 ✅:
   https://www.nutube.kr/
   https://www.nutube.kr/blog
   https://www.nutube.kr/blog/algorithm-seo

404 페이지가 떠야 정상 ✅:
   https://www.nutube.kr/knowhow/youtube-algorithm
   https://www.nutube.kr/keyword
   https://www.nutube.kr/plan

→ 404가 떠야 정리 성공!


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
[ 이 ZIP의 정리 내역 ]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 삭제된 옛날 폴더 (18개):
   analytics, assets, configure, create, done, imagegen,
   keyword, knowhow, login, metadata, news, plan,
   platform, processing, script, studio, workflow

✅ 보존된 NuTube 핵심 (10개):
   blog (58편), about, contact, privacy, terms,
   publish, api, _shared, _lib, rss.xml

✅ AlgoMaker → NuTube 텍스트 일괄 교체: 32개 파일

✅ 박 대표님 자산 100% 보존:
   V18Shell, V17Shell, V11Shell, V10Shell
   ContentProtection, RewardedAd, AdGate
   박 실장 11공식, 박 실장 7계명
   contentEngine, scenarioEngine, promptEngine
   58편 블로그 글 + 58개 SVG 썸네일


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

수고하셨습니다.
중간에 막히시는 부분 있으면 캡처와 함께 알려주세요.
