module.exports = { plugins: {} };
